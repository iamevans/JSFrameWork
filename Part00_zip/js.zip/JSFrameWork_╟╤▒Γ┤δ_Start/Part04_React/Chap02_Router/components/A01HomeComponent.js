
import React from 'react';

const A01HomeComponent = () => {
    return (
        <div>
            <h5>HOME</h5>

            <div>This is Home Component.</div>
        </div>
    )
}
export default A01HomeComponent;
