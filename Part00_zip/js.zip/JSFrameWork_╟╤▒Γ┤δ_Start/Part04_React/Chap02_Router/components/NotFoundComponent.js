
import React from 'react';

const NotFoundComponent = () => {
    return (
        <div>
            <h5>Dear friend, this URL was not found</h5>
        </div>
    )
}
export default NotFoundComponent;
