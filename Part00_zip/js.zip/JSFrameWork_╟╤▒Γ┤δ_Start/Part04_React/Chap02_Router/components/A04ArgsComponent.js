
import React from 'react';
// import queryString from 'query-string';

const A04ArgsComponent = (props) => {


    return (
        <div>
            <h5>Argument Component</h5>
            <div>This is Argument Component</div>
            <br />

            <div>
                pathname:  <br/>
                search: <br/>
                hash: 
            </div>
            <br />

            <div>
                Name: <br/>
                Age: <br/>
                Address: 
            </div>
            <br />
        </div>
    )
}
export default A04ArgsComponent;