
import React from 'react'

const A03RefComponent = () => {

    return (
        <div className="card-body">
            <h3>A03 DOM Reference</h3>

            <h4>Children</h4>
            <div>
                    
            </div>
            <br />
            <br />

            <h4>DOM 참조</h4>
            <div className="input-group">
                <input type="text" className="form-control"/>
                <div className="input-group-append">
                    <button className="btn btn-primary">Click</button>
                </div>
            </div>
            <br />
            <br/>
        </div>
    )
}
export default A03RefComponent;