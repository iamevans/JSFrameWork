import { Component } from '@angular/core';

@Component({
    selector: 'description',
    template: `
        <p>This is great product!!</p>
    `
})
export class DescriptionComponent{

}