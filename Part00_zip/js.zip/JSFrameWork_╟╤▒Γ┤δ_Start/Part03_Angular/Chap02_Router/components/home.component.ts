import { Component } from '@angular/core'

@Component({
    selector: 'home',
    template: `
        <div>
            <h5>Home Component</h5>

            This is Home Component.
        </div>
    `
})
export class HomeComponent{

}