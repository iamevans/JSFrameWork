import { Component } from '@angular/core';

@Component({
    selector: 'luxury',
    template: `
        <div>
            <h5>Luxury Component Lazy</h5>
            Network 모드에서 로드되는 상황을 체크.
        </div>
        
    `
})
export class LuxuryLazyComponent{
    
}