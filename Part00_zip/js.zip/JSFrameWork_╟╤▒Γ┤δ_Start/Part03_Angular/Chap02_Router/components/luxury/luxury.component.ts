import { Component } from '@angular/core';

@Component({
    selector: 'luxury',
    template: `
        <div>
            <h5>Luxury Component</h5>
            This is Luxury Component
        </div>
    `
})
export class LuxuryComponent{
    
}