<template>
    <div>
        <h6>404 Not Found...</h6>
    </div>
</template>
