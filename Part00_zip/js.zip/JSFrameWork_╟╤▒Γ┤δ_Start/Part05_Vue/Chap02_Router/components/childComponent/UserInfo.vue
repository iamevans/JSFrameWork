<template>
    <div>
        <h6>UserInfo Component</h6>
        This is UserInfo Component
    </div>
</template>

<script>
export default {
    name: 'UserInfo'
}
</script>

<style>

</style>