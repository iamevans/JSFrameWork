<template>
    <div>
        <h6>Profile Component</h6>
        This is Profile Component
    </div>
</template>

<script>
export default {
    name: 'Profile'
}
</script>

<style>

</style>