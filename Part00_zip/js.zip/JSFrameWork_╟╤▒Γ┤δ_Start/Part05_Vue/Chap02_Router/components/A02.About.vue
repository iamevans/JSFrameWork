<template>
    <div>
        <h6>A02 About Component</h6>
        This is About Component
        <br>
        <br>

        Name: 
    </div>
</template>

<script>
export default {
    name: 'About'
}
</script>

<style>

</style>