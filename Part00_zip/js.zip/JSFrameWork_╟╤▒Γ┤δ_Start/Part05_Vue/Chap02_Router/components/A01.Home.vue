<template>
    <div>
        <h6>A01 Home Component</h6>
        This is Home Component
    </div>
</template>

<script>
export default {
    name: 'Home'
}
</script>

<style>

</style>