


console.log(num);
console.log(onAdd(10, 20));
console.log(long(10, 20));

console.log(onMulti(10, 20));
console.log(name);



