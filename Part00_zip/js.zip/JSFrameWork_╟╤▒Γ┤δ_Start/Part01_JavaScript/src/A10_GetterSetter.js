

class Jumsu {

    constructor(name, kor) {
        this._name = name;
    }

    
};


let nolbu = new Jumsu('Nolbu', 100, 90);
console.log(nolbu._name);                       // Nolbu




