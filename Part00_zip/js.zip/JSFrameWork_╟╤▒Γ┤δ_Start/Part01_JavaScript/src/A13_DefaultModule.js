

function onMulti(x, y) {
    return x * y;
}

let name = 'NolBu';

