
namespace A09Class {

    class Jumsu {
        
    }

    

}