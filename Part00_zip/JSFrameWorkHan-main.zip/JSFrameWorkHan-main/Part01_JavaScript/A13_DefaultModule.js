

export default function (x, y) {
    return x * y;
}

export let name = 'NolBu';

