

export let num = 10.25;

export function onAdd(x, y) {
    return x + y;
}

export function longNameFunction() {
    return 'longNameFunction';
}


