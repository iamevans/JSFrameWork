
import { Component } from '@angular/core';

@Component({
    selector: '<a-comp>',
    template: `
        <h3>A Component</h3>

        <div>This is A Component</div>

        <b-comp></b-comp>
    `,
})
export class AComponent {

}