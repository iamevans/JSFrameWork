
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'b-comp',
    template: `
        <h3>B Component</h3>

        <div>
            This is B Component
        </div>
    `,
    styles: []
})
export class BComponent {
    constructor() { }
}
